"""Tests for SignBridge.  Run:  python tests/test_pipeline.py   (or: pytest tests/)

The language-layer tests need no LLM: a fake backend records the prompts and
returns canned JSON. Recognizer / app tests are skipped if torch is missing.
"""
import json, os, sys
import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
os.chdir(ROOT)
import llm  # noqa: E402

try:
    import torch  # noqa: F401
    HAVE_TORCH = True
except ImportError:
    HAVE_TORCH = False


class FakeBackend(llm.Backend):
    name = "fake"
    def __init__(self, reply):
        self.reply, self.calls = reply, []
    def chat(self, system, user):
        self.calls.append((system, user))
        return self.reply if isinstance(self.reply, str) else json.dumps(self.reply)


GOOD = {"intent": {"act": "ask_location", "topic": "LIBRARY"}, "interpretation": "Where is the library?",
        "needs_clarification": False, "response": "Building B, second floor."}


def S(g, c, alts=()):
    return {"gloss": g, "conf": c, "alts": [list(a) for a in alts]}


def test_policy_thresholds():
    assert llm.assess([S("LIBRARY", 0.95, [("BATHROOM", 0.03)])])["decision"] == "respond"
    assert llm.assess([S("LIBRARY", 0.65, [("BATHROOM", 0.30)])])["decision"] == "llm_decides"
    assert llm.assess([S("LIBRARY", 0.45, [("BATHROOM", 0.20)])])["decision"] == "clarify"
    # near-tie above LOW is still a clarification
    assert llm.assess([S("LIBRARY", 0.51, [("BATHROOM", 0.47)])])["decision"] == "clarify"
    # the least confident sign decides, and is the one asked about
    a = llm.assess([S("WHERE", 0.97), S("LIBRARY", 0.45, [("BATHROOM", 0.40)])])
    assert a["decision"] == "clarify" and a["weakest"] == 1
    q = llm.clarification_question([S("WHERE", 0.97), S("LIBRARY", 0.45, [("BATHROOM", 0.40)])], 1)
    assert "library" in q and "bathroom" in q and q.endswith("?")


def test_model_a_direct():
    res = llm.ask([], [S("WHERE", 0.9), S("FOOD", 0.9)], {}, "direct", backend=FakeBackend(GOOD))
    assert res["source"] == "direct" and res["needs_clarification"] is False
    assert res["interpretation"] == "Where cafeteria."
    assert res["intent"] == {"act": "ask_location", "topic": "FOOD"}


def test_gate_skips_llm_for_low_confidence():
    fb = FakeBackend(GOOD)
    res = llm.ask([], [S("HELP", 0.42, [("HELLO", 0.40)])], {}, "ours", backend=fb)
    assert res["needs_clarification"] and res["source"] == "confidence gate"
    assert fb.calls == [], "Model C must not call the LLM below the threshold"
    assert "help" in res["response"] and "hello" in res["response"]
    # the ablation and Model B do call the LLM
    for mode in ("ours_nogate", "llm"):
        fb2 = FakeBackend(GOOD)
        llm.ask([], [S("HELP", 0.42, [("HELLO", 0.40)])], {}, mode, backend=fb2)
        assert len(fb2.calls) == 1


def test_b_and_c_prompts_differ_only_in_confidence_info():
    segs = [S("WHERE", 0.96, [("WHO", 0.02)]), S("LIBRARY", 0.66, [("BATHROOM", 0.30)])]
    hist = llm.record_turn([], [S("HELLO", 0.95)], {"interpretation": "Hello.", "intent": {"act": "greet", "topic": "NONE"},
                                                     "needs_clarification": False, "response": "Hi!"})
    fb_b, fb_c = FakeBackend(GOOD), FakeBackend(GOOD)
    llm.ask(hist, segs, {}, "llm", backend=fb_b)
    llm.ask(hist, segs, {}, "ours", backend=fb_c)
    sys_b, user_b = fb_b.calls[0]
    sys_c, user_c = fb_c.calls[0]
    assert "confidence" not in user_b.lower() and "BATHROOM" not in user_b
    assert "0.66" in user_c and "BATHROOM 0.30" in user_c and "medium" in user_c
    assert "Hi!" in user_b and "Hi!" in user_c, "both B and C get the conversation history"
    assert sys_c.startswith(sys_b) and len(sys_c) > len(sys_b)


def test_llm_output_parsing():
    fenced = "```json\n" + json.dumps({**GOOD, "intent": {"act": "Ask_Location", "topic": "library"}}) + "\n```"
    res = llm.ask([], [S("WHERE", 0.9), S("LIBRARY", 0.9)], {}, "ours", backend=FakeBackend(fenced))
    assert res["intent"] == {"act": "ask_location", "topic": "LIBRARY"}
    bad_labels = {**GOOD, "intent": {"act": "dance", "topic": "MOON"}}
    res = llm.ask([], [S("WHERE", 0.9), S("LIBRARY", 0.9)], {}, "ours", backend=FakeBackend(bad_labels))
    assert res["intent"] == {"act": "unknown", "topic": "NONE"}
    res = llm.ask([], [S("WHERE", 0.9)], {}, "ours", backend=FakeBackend("not json at all"))
    assert res.get("error") and res["needs_clarification"] is False
    # LLM asks but gives no text -> we fill in a question
    res = llm.ask([], [S("WHERE", 0.7), S("LIBRARY", 0.7, [("BATHROOM", 0.2)])], {}, "ours",
                  backend=FakeBackend({**GOOD, "needs_clarification": True, "response": ""}))
    assert res["response"].endswith("?")


def test_rules_fallback_uses_history():
    rb = llm.RulesBackend()
    hist = []
    r1 = llm.ask(hist, [S("WHERE", 0.95), S("LIBRARY", 0.93)], {}, "ours", backend=rb)
    llm.record_turn(hist, [S("WHERE", 0.95), S("LIBRARY", 0.93)], r1)
    r2 = llm.ask(hist, [S("WHEN", 0.92)], {}, "ours", backend=rb)
    assert r2["intent"] == {"act": "ask_time", "topic": "LIBRARY"} and "rules" in r2["source"]
    # clarification, then a one-sign answer keeps the original question
    hist = []
    segs = [S("WHEN", 0.95), S("LIBRARY", 0.51, [("BATHROOM", 0.47)])]
    r3 = llm.ask(hist, segs, {}, "ours", backend=rb)
    assert r3["needs_clarification"]
    llm.record_turn(hist, segs, r3)
    r4 = llm.ask(hist, [S("BATHROOM", 0.94)], {}, "ours", backend=rb)
    assert r4["intent"] == {"act": "ask_time", "topic": "BATHROOM"}


def test_testset_is_well_formed():
    path = os.path.join(ROOT, "eval", "testset.jsonl")
    cases = [json.loads(l) for l in open(path)]
    assert len(cases) >= 200
    for c in cases:
        assert c["acceptable"] and set(c["acceptable"]) <= {"respond", "clarify"}
        assert c["gold_intent"]["act"] in llm.ACTS and c["gold_intent"]["topic"] in llm.TOPICS
        for s in c["segments"]:
            assert 0 <= s["conf"] <= 1 and all(0 <= a[1] <= 1 for a in s["alts"])
        if c["category"] in ("near_tie", "low_conf"):
            assert llm.assess(c["segments"])["decision"] == "clarify"


def test_sign_model():
    if not HAVE_TORCH:
        print("  (skipped: torch not installed)")
        return
    import sign_model
    for n in (0, 1, 25):
        assert sign_model.resample(np.random.randn(n, 149).astype(np.float32)).shape == (32, 149)
    assert sign_model.segments(np.zeros((20, 149))) == []
    rec = sign_model.Recognizer()
    if rec.ready:
        f = next(os.path.join(dp, x) for dp, _, fs in os.walk("data") for x in fs if x.endswith(".npy"))
        out, cues = rec.predict(np.load(f))
        for o in out:
            assert 0 <= o["conf"] <= 1 and len(o["alts"]) <= 2
            assert abs(o["conf"] + sum(p for _, p in o["alts"])) <= 1.0001


def test_app():
    if not HAVE_TORCH:
        print("  (skipped: torch not installed)")
        return
    from fastapi.testclient import TestClient
    import app
    c = TestClient(app.app)
    st = c.get("/api/status").json()
    assert "llm_backend" in st and "trained_on" in st
    r = c.post("/api/interpret", json={"session": "t", "mode": "ours",
                                         "simulate": {"glosses": ["WHERE", "LIBRARY"], "conf": 0.51,
                                                      "alts": [["BATHROOM", 0.47]]}}).json()
    assert r["result"]["needs_clarification"] is True
    r = c.post("/api/interpret", json={"session": "t", "mode": "direct",
                                         "simulate": {"glosses": ["WHERE", "LIBRARY"], "conf": 0.9}}).json()
    assert r["result"]["source"] == "direct"
    # Two-way conversation hearing interlocutor turn
    hr = c.post("/api/hearing_turn", json={"session": "t", "text": "The library is on the 2nd floor."}).json()
    assert hr["status"] == "ok" and hr["speaker"] == "hearing_interlocutor"
    # Human evaluation feedback
    fb = c.post("/api/feedback", json={"turn_id": "test_1", "rating": 5, "metric": "naturalness"}).json()
    assert fb["saved"] is True
    assert c.post("/api/collect", json={"label": "X", "signer": "", "frames": [[0] * 149] * 10}).json()["saved"] is False
    assert c.post("/api/reset", json={"session": "t"}).json()["ok"]


if __name__ == "__main__":
    tests = [v for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for t in tests:
        print(f"{t.__name__} ...")
        t()
    print(f"ALL {len(tests)} TESTS PASSED")
