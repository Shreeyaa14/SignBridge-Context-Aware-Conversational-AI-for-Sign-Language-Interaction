"""
SYNTHETIC landmark generator for SignBridge (pipeline smoke tests only).

Writes 50 hand-scripted (T, 149) sequences per gloss to data/synthetic/<GLOSS>/.
The motion paths are rough approximations written by hand and several do NOT
match the real ASL sign. A model trained on this data only learns this
generator; never report its accuracy as sign-recognition performance.
Real training data comes from the web app's Collect panel (data/recorded/).
"""
import os, sys, json, time, random, glob
import numpy as np

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
os.chdir(ROOT_DIR)
sys.path.insert(0, ROOT_DIR)


VOCAB = [
    "HELLO", "GOODBYE", "YES", "NO", "HELP", "THANK-YOU", "SORRY", "UNDERSTAND",
    "NOT-UNDERSTAND", "REPEAT", "WHERE", "WHAT", "WHO", "LIBRARY", "CLASSROOM",
    "BATHROOM", "FOOD", "WATER", "DOCTOR", "APPOINTMENT", "TOMORROW", "OFFICE", "WHEN"
]

def generate_sign_samples():
    """
    Generate rough hand-scripted 149-d landmark sequences for all 23 signs.
    Layout per frame:
      - 0..62: Left hand (21 landmarks * (x,y,z))
      - 63..125: Right hand (21 landmarks * (x,y,z))
      - 126..146: Body (7 landmarks: nose, l_sh, r_sh, l_elb, r_elb, l_wri, r_wri)
      - 147: Brow ratio
      - 148: Mouth open ratio
    """
    print("Generating training samples for 23 vocabulary signs...")
    np.random.seed(42)
    random.seed(42)

    def open_hand():
        pts = np.zeros((21, 3), dtype=np.float32)
        pts[1:5, 0] = np.linspace(0.04, 0.08, 4)
        pts[1:5, 1] = np.linspace(0.02, 0.06, 4)
        pts[5:9, 0] = np.linspace(0.02, 0.03, 4)
        pts[5:9, 1] = np.linspace(0.06, 0.16, 4)
        pts[9:13, 0] = np.linspace(0.00, 0.00, 4)
        pts[9:13, 1] = np.linspace(0.07, 0.18, 4)
        pts[13:17, 0] = np.linspace(-0.02, -0.03, 4)
        pts[13:17, 1] = np.linspace(0.06, 0.16, 4)
        pts[17:21, 0] = np.linspace(-0.04, -0.06, 4)
        pts[17:21, 1] = np.linspace(0.04, 0.12, 4)
        return pts

    def fist_hand():
        pts = np.zeros((21, 3), dtype=np.float32)
        # Thumb rests alongside or points slightly up (thumbs-up / A-handshape)
        pts[1:5, 0] = np.linspace(0.02, 0.04, 4)
        pts[1:5, 1] = np.linspace(0.03, 0.09, 4)
        pts[1:5, 2] = np.linspace(0.02, 0.04, 4)
        # 4 fingers curled tightly into palm (knuckles higher than curled tips)
        for s in [5, 9, 13, 17]:
            pts[s, 1] = 0.06  # MCP knuckle
            pts[s+1:s+4, 1] = np.linspace(0.05, 0.02, 3)  # curled downwards towards palm
            pts[s+1:s+4, 2] = np.linspace(0.03, 0.05, 3)  # forward depth
        return pts

    def index_pointing_hand():
        pts = fist_hand()
        pts[5:9, 0] = np.linspace(0.01, 0.02, 4)
        pts[5:9, 1] = np.linspace(0.06, 0.17, 4)
        pts[5:9, 2] = 0.0
        return pts

    def get_sign_trajectory(gloss, T):
        t = np.linspace(0, 1, T)
        rw = np.zeros((T, 3), dtype=np.float32)
        lw = np.zeros((T, 3), dtype=np.float32)
        r_hand_type = "open"
        l_hand_type = "none"
        brow = np.full(T, 0.18, dtype=np.float32)
        mouth = np.full(T, 0.04, dtype=np.float32)

        # Baseline vertical offset to account for signer sitting height variations
        h_jitter = random.uniform(-0.10, 0.10)

        if gloss == "HELLO":
            rw[:, 0] = 0.38 + 0.20 * t
            rw[:, 1] = 0.42 + 0.08 * np.sin(np.pi * t) + h_jitter
            rw[:, 2] = -0.1 + 0.05 * t
            r_hand_type = "open"
            brow += 0.03 * np.sin(np.pi * t)

        elif gloss == "GOODBYE":
            rw[:, 0] = 0.35 + 0.08 * np.sin(4 * np.pi * t)
            rw[:, 1] = 0.38 + h_jitter
            r_hand_type = "open"

        elif gloss == "YES":
            rw[:, 0] = 0.25
            rw[:, 1] = 0.05 + 0.10 * np.sin(3 * np.pi * t) + h_jitter
            rw[:, 2] = -0.05
            r_hand_type = "fist"

        elif gloss == "NO":
            rw[:, 0] = 0.22
            rw[:, 1] = 0.08 - 0.05 * np.cos(3 * np.pi * t) + h_jitter
            r_hand_type = "pinch"
            brow -= 0.02

        elif gloss == "HELP":
            # Approximation of ASL HELP: Dominant fist lifting UPWARDS from chest/torso
            # Start Y: -0.28 to -0.05; Lift delta: +0.18 to +0.30
            y_base = random.uniform(-0.30, -0.08) + h_jitter
            lift_amount = random.uniform(0.18, 0.28)
            if random.random() < 0.65:
                # Two-handed standard: left open palm underneath, right fist lifting on it
                lw[:, 0] = random.uniform(-0.14, -0.04)
                lw[:, 1] = y_base + lift_amount * t
                lw[:, 2] = -0.1
                rw[:, 0] = lw[:, 0] + random.uniform(-0.02, 0.02)
                rw[:, 1] = lw[:, 1] + 0.05
                rw[:, 2] = -0.08
                r_hand_type = "fist"; l_hand_type = "open"
            else:
                # One-handed dominant lift variation
                rw[:, 0] = random.uniform(-0.02, 0.12)
                rw[:, 1] = y_base + lift_amount * t
                rw[:, 2] = -0.08
                r_hand_type = "fist"; l_hand_type = "none"

        elif gloss == "THANK-YOU":
            # Approximation of ASL THANK-YOU: Starts at chin/lips, moves DOWN and forward
            y_chin = random.uniform(0.15, 0.28) + h_jitter
            rw[:, 0] = 0.05 * (1 - t)
            rw[:, 1] = y_chin - 0.22 * t
            rw[:, 2] = -0.05 - 0.2 * t
            r_hand_type = "open"

        elif gloss == "SORRY":
            # Approximation of ASL SORRY: Fist circular motion on center chest
            y_chest = random.uniform(-0.18, -0.05) + h_jitter
            rw[:, 0] = 0.06 * np.cos(3 * np.pi * t)
            rw[:, 1] = y_chest + 0.06 * np.sin(3 * np.pi * t)
            r_hand_type = "fist"

        elif gloss == "UNDERSTAND":
            rw[:, 0] = 0.30
            rw[:, 1] = 0.35 + 0.15 * (t ** 2) + h_jitter
            r_hand_type = "index"
            brow += 0.05 * t

        elif gloss == "NOT-UNDERSTAND":
            rw[:, 0] = 0.30
            rw[:, 1] = 0.35 + 0.12 * (t ** 2) + h_jitter
            r_hand_type = "index"
            brow -= 0.04
            mouth += 0.03

        elif gloss == "REPEAT":
            y_rep = random.uniform(-0.20, -0.05) + h_jitter
            lw[:, 0] = -0.15; lw[:, 1] = y_rep
            rw[:, 0] = 0.18 - 0.28 * t; rw[:, 1] = y_rep + 0.08 - 0.08 * t
            l_hand_type = "open"; r_hand_type = "open"

        elif gloss == "WHERE":
            rw[:, 0] = 0.22 + 0.10 * np.sin(4 * np.pi * t)
            rw[:, 1] = 0.05 + h_jitter
            r_hand_type = "index"
            brow += 0.08

        elif gloss == "WHAT":
            y_what = random.uniform(-0.28, -0.10) + h_jitter
            rw[:, 0] = 0.26 + 0.05 * np.sin(3 * np.pi * t); rw[:, 1] = y_what
            lw[:, 0] = -0.26 - 0.05 * np.sin(3 * np.pi * t); lw[:, 1] = y_what
            r_hand_type = "open"; l_hand_type = "open"
            brow += 0.07

        elif gloss == "WHO":
            rw[:, 0] = 0.04 * np.cos(3 * np.pi * t)
            rw[:, 1] = 0.18 + 0.04 * np.sin(3 * np.pi * t) + h_jitter
            r_hand_type = "index"
            mouth += 0.05

        elif gloss == "LIBRARY":
            y_lib = random.uniform(-0.10, 0.10) + h_jitter
            rw[:, 0] = 0.22 + 0.10 * np.cos(2 * np.pi * t)
            rw[:, 1] = y_lib + 0.10 * np.sin(2 * np.pi * t)
            r_hand_type = "index"

        elif gloss == "CLASSROOM":
            y_class = random.uniform(-0.20, -0.05) + h_jitter
            rw[:, 0] = 0.25 - 0.15 * t; rw[:, 1] = y_class; rw[:, 2] = -0.1 * np.sin(np.pi * t)
            lw[:, 0] = -0.25 + 0.15 * t; lw[:, 1] = y_class; lw[:, 2] = -0.1 * np.sin(np.pi * t)
            r_hand_type = "open"; l_hand_type = "open"

        elif gloss == "BATHROOM":
            rw[:, 0] = 0.25 + 0.08 * np.sin(5 * np.pi * t)
            rw[:, 1] = 0.05 + h_jitter
            r_hand_type = "fist"

        elif gloss == "FOOD":
            rw[:, 0] = 0.02
            rw[:, 1] = 0.20 + 0.06 * np.abs(np.sin(2 * np.pi * t)) + h_jitter
            r_hand_type = "pinch"
            mouth += 0.04 * np.abs(np.sin(2 * np.pi * t))

        elif gloss == "WATER":
            rw[:, 0] = 0.04
            rw[:, 1] = 0.18 + 0.04 * np.sin(3 * np.pi * t) + h_jitter
            r_hand_type = "open"

        elif gloss == "DOCTOR":
            y_doc = random.uniform(-0.22, -0.08) + h_jitter
            lw[:, 0] = -0.15; lw[:, 1] = y_doc
            rw[:, 0] = -0.15 + 0.03 * np.sin(3 * np.pi * t); rw[:, 1] = y_doc + 0.03
            l_hand_type = "open"; r_hand_type = "open"

        elif gloss == "APPOINTMENT":
            y_app = random.uniform(-0.20, -0.06) + h_jitter
            lw[:, 0] = -0.12; lw[:, 1] = y_doc if 'y_doc' in locals() else y_app
            rw[:, 0] = -0.12 + 0.12 * (1 - t) * np.cos(2 * np.pi * t)
            rw[:, 1] = y_app + 0.12 * (1 - t)
            l_hand_type = "open"; r_hand_type = "fist"

        elif gloss == "TOMORROW":
            rw[:, 0] = 0.20 + 0.12 * t
            rw[:, 1] = 0.22 - 0.05 * t + h_jitter
            r_hand_type = "fist"

        elif gloss == "OFFICE":
            y_off = random.uniform(-0.22, -0.08) + h_jitter
            rw[:, 0] = 0.22; rw[:, 1] = y_off - 0.15 * t
            lw[:, 0] = -0.22; lw[:, 1] = y_off - 0.15 * t
            r_hand_type = "open"; l_hand_type = "open"

        elif gloss == "WHEN":
            y_when = random.uniform(-0.05, 0.15) + h_jitter
            lw[:, 0] = -0.05; lw[:, 1] = y_when
            rw[:, 0] = -0.05 + 0.12 * (1 - t) * np.cos(2 * np.pi * t)
            rw[:, 1] = y_when + 0.12 * (1 - t) * np.sin(2 * np.pi * t)
            l_hand_type = "index"; r_hand_type = "index"
            brow += 0.06

        return rw, lw, r_hand_type, l_hand_type, brow, mouth

    force_rebuild = "--force" in sys.argv or "-f" in sys.argv
    total_samples = 0
    for gloss in VOCAB:
        target_dir = f"data/synthetic/{gloss}"
        os.makedirs(target_dir, exist_ok=True)
        existing = glob.glob(f"{target_dir}/*.npy")
        if not force_rebuild and len(existing) >= 45:
            print(f"Gloss {gloss} already has {len(existing)} samples.")
            total_samples += len(existing)
            continue

        if force_rebuild:
            for f in existing:
                try: os.remove(f)
                except Exception: pass

        for s_idx in range(50):
            T = random.randint(24, 38)
            rw, lw, r_type, l_type, brow, mouth = get_sign_trajectory(gloss, T)

            scale_factor = random.uniform(0.80, 1.25)
            shift_x = random.uniform(-0.15, 0.15)
            shift_y = random.uniform(-0.12, 0.12)

            feat = np.zeros((T, 149), dtype=np.float32)

            for t in range(T):
                if r_type != "none":
                    if r_type == "open": r_base = open_hand()
                    elif r_type == "fist": r_base = fist_hand()
                    elif r_type == "index": r_base = index_pointing_hand()
                    else: r_base = fist_hand()
                    
                    rh_pts = r_base.copy()
                    rh_pts[:, 0] += (rw[t, 0] + shift_x) * scale_factor
                    rh_pts[:, 1] += (rw[t, 1] + shift_y) * scale_factor
                    rh_pts[:, 2] += rw[t, 2] * scale_factor
                    rh_pts += np.random.normal(0, 0.005, rh_pts.shape).astype(np.float32)
                    feat[t, 63:126] = rh_pts.flatten()

                if l_type != "none":
                    if l_type == "open": l_base = open_hand()
                    elif l_type == "fist": l_base = fist_hand()
                    elif l_type == "index": l_base = index_pointing_hand()
                    else: l_base = open_hand()

                    lh_pts = l_base.copy()
                    lh_pts[:, 0] = -lh_pts[:, 0]
                    lh_pts[:, 0] += (lw[t, 0] + shift_x) * scale_factor
                    lh_pts[:, 1] += (lw[t, 1] + shift_y) * scale_factor
                    lh_pts[:, 2] += lw[t, 2] * scale_factor
                    lh_pts += np.random.normal(0, 0.005, lh_pts.shape).astype(np.float32)
                    feat[t, 0:63] = lh_pts.flatten()

                body = np.zeros((7, 3), dtype=np.float32)
                body[0] = [0.0 + shift_x*0.2, 0.45 + shift_y*0.2, 0.0]
                body[1] = [-0.5, 0.0, 0.0]
                body[2] = [0.5, 0.0, 0.0]
                body[3] = [-0.6, -0.3, 0.0]
                body[4] = [0.6, -0.3, 0.0]
                body[5] = [lw[t, 0], lw[t, 1], lw[t, 2]] if l_type != "none" else [-0.5, -0.6, 0.0]
                body[6] = [rw[t, 0], rw[t, 1], rw[t, 2]] if r_type != "none" else [0.5, -0.6, 0.0]
                feat[t, 126:147] = body.flatten()

                feat[t, 147] = float(brow[t] + random.uniform(-0.01, 0.01))
                feat[t, 148] = float(mouth[t] + random.uniform(-0.005, 0.005))

            ts = int(time.time() * 1000) + s_idx
            np.save(f"{target_dir}/{ts}_{s_idx}.npy", feat)
            total_samples += 1

    print(f"Dataset preparation complete: {total_samples} samples across {len(VOCAB)} classes.")

if __name__ == "__main__":
    generate_sign_samples()
