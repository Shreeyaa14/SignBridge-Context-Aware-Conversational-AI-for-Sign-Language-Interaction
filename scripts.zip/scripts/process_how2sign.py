"""Extract, normalize, and segment How2Sign 2D keypoints into SignBridge 149-d format.

Reads OpenPose 2D keypoint tarballs (val_2D_keypoints.tar.gz, test_2D_keypoints.tar.gz, train_2D_keypoints.tar.gz)
and matches clips using How2Sign aligned transcripts. Converts OpenPose keypoints into
shoulder-normalized (T, 149) arrays matching MediaPipe Holistic features.
Saves to data/how2sign/<GLOSS>/<signer>__how2sign_<clip>.npy.
"""
import os, sys, json, csv, re, tarfile
from collections import defaultdict
import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import sign_model

VOCAB_MAP = {
    "HELLO": ["HELLO", "HI", "HEY"],
    "GOODBYE": ["GOODBYE", "BYE"],
    "YES": ["YES", "YEAH"],
    "NO": ["NO", "NOPE"],
    "HELP": ["HELP", "ASSIST"],
    "THANKYOU": ["THANK YOU", "THANKS", "THANK-YOU"],
    "SORRY": ["SORRY", "APOLOGIZE"],
    "UNDERSTAND": ["UNDERSTAND", "UNDERSTOOD"],
    "NOT-UNDERSTAND": ["NOT UNDERSTAND", "DON'T UNDERSTAND", "DO NOT UNDERSTAND"],
    "REPEAT": ["REPEAT", "AGAIN"],
    "WHERE": ["WHERE"],
    "WHAT": ["WHAT"],
    "WHO": ["WHO"],
    "WHEN": ["WHEN"],
    "LIBRARY": ["LIBRARY", "BOOKSTORE"],
    "CLASSROOM": ["CLASSROOM", "CLASS"],
    "BATHROOM": ["BATHROOM", "RESTROOM", "TOILET"],
    "FOOD": ["FOOD", "EAT", "MEAL", "CAFETERIA"],
    "WATER": ["WATER", "DRINK"],
    "DOCTOR": ["DOCTOR", "PHYSICIAN", "NURSE", "CLINIC"],
    "APPOINTMENT": ["APPOINTMENT", "SCHEDULE"],
    "TOMORROW": ["TOMORROW"],
    "OFFICE": ["OFFICE", "DESK", "ADMINISTRATION"]
}

def load_clip_gloss_map(max_per_gloss=20, under_only=None):
    """Scan transcript TSVs to map clip IDs to target vocabulary glosses."""
    clip_to_gloss = {}
    gloss_counts = defaultdict(int)
    
    tsvs = [
        os.path.join(ROOT, "data", "new data", "how2sign_realigned_train.csv")
    ]
    
    for tsv_path in tsvs:
        if not os.path.exists(tsv_path):
            continue
        with open(tsv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                clip_id = row.get("SENTENCE_NAME", "").strip()
                sent = row.get("SENTENCE", "").strip().upper()
                if not clip_id or not sent:
                    continue
                
                for gloss, triggers in VOCAB_MAP.items():
                    if under_only and gloss not in under_only:
                        continue
                    if gloss_counts[gloss] >= max_per_gloss:
                        continue
                    matched = False
                    for trig in triggers:
                        pattern = r'\b' + re.escape(trig) + r'\b'
                        if re.search(pattern, sent):
                            matched = True
                            break
                    if matched:
                        clip_to_gloss[clip_id] = (gloss, row.get("VIDEO_ID", "how2sign"))
                        gloss_counts[gloss] += 1
                        break
                        
    print(f"Matched {len(clip_to_gloss)} clips across {len(gloss_counts)} underrepresented classes in train.")
    for g, c in sorted(gloss_counts.items()):
        print(f"  {g}: {c} clips")
    return clip_to_gloss

def convert_openpose_to_149d(p):
    if not p:
        return np.zeros(149, dtype=np.float32)
        
    pose = p.get("pose_keypoints_2d", [])
    lh = p.get("hand_left_keypoints_2d", [])
    rh = p.get("hand_right_keypoints_2d", [])
    face = p.get("face_keypoints_2d", [])
    
    if len(pose) >= 18 and (pose[17] > 0.05 or pose[8] > 0.05):
        lx, ly = pose[15], pose[16]
        rx, ry = pose[6], pose[7]
        cx, cy = (lx + rx) / 2.0, (ly + ry) / 2.0
        sc = float(np.hypot(lx - rx, ly - ry))
        if sc <= 1e-4: sc = 1.0
    else:
        cx, cy, sc = 0.0, 0.0, 1.0

    def norm_hand(pts):
        if not pts or len(pts) < 63:
            return [0.0] * 63
        out = []
        for i in range(21):
            x, y, conf = pts[3 * i], pts[3 * i + 1], pts[3 * i + 2]
            if conf < 0.05:
                out.extend([0.0, 0.0, 0.0])
            else:
                out.extend([(cx - x) / sc, (cy - y) / sc, 0.0])
        return out

    lh_feat = norm_hand(lh)
    rh_feat = norm_hand(rh)

    body_indices = [0, 5, 2, 6, 3, 7, 4]
    body_feat = []
    for idx in body_indices:
        if len(pose) > 3 * idx + 1:
            bx, by, bconf = pose[3 * idx], pose[3 * idx + 1], pose[3 * idx + 2]
            if bconf < 0.05:
                body_feat.extend([0.0, 0.0, 0.0])
            else:
                body_feat.extend([(cx - bx) / sc, (cy - by) / sc, 0.0])
        else:
            body_feat.extend([0.0, 0.0, 0.0])

    brow, mouth = 0.18, 0.04
    if len(face) >= 70 * 3:
        h_face = np.hypot(face[3 * 8] - face[3 * 27], face[3 * 8 + 1] - face[3 * 27 + 1])
        if h_face > 1e-3:
            brow = float(np.hypot(face[3 * 19] - face[3 * 37], face[3 * 19 + 1] - face[3 * 37 + 1]) / h_face)
            mouth = float(np.hypot(face[3 * 51] - face[3 * 57], face[3 * 51 + 1] - face[3 * 57 + 1]) / h_face)

    return np.array(lh_feat + rh_feat + body_feat + [brow, mouth], dtype=np.float32)

def process_tarball(tar_path, clip_to_gloss, out_dir, max_frames=50000):
    if not os.path.exists(tar_path):
        return 0

    print(f"\nProcessing {os.path.basename(tar_path)}...")
    saved_count = 0
    clip_frames = defaultdict(list)
    frames_read = 0
    
    with tarfile.open(tar_path, "r:gz") as tar:
        for member in tar:
            if not member.name.endswith(".json") or "openpose_output/json/" not in member.name:
                continue
            parts = member.name.split("/")
            if len(parts) < 4:
                continue
            clip_id = parts[2]
            if clip_id not in clip_to_gloss:
                continue
                
            try:
                f = tar.extractfile(member)
                if not f:
                    continue
                d = json.load(f)
                people = d.get("people", [])
                p = people[0] if people else None
                feat = convert_openpose_to_149d(p)
                clip_frames[clip_id].append((member.name, feat))
                frames_read += 1
                if frames_read >= max_frames:
                    print(f"Reached max frames limit ({max_frames}) for this tarball.")
                    break
            except Exception:
                continue

    for clip_id, frames_with_names in clip_frames.items():
        if len(frames_with_names) < 8:
            continue
        frames_with_names.sort(key=lambda x: x[0])
        seq = np.stack([x[1] for x in frames_with_names], axis=0)
        
        gloss, signer = clip_to_gloss[clip_id]
        clean_gloss = re.sub(r"[^A-Z0-9-]", "", gloss)
        target_dir = os.path.join(out_dir, clean_gloss)
        os.makedirs(target_dir, exist_ok=True)
        
        segs = sign_model.segments(seq, gap=5, min_len=8)
        if not segs:
            p = sign_model.hands_present(seq)
            if p.sum() >= 8:
                idx = np.where(p)[0]
                segs = [(int(idx[0]), int(idx[-1] + 1))]
            else:
                segs = [(0, len(seq))]
                
        for s_idx, (start, end) in enumerate(segs[:2]):
            sub = seq[start:end]
            if len(sub) >= 8:
                out_path = os.path.join(target_dir, f"{signer}__how2sign_{clip_id}_{s_idx}.npy")
                np.save(out_path, sub)
                saved_count += 1

    print(f"Saved {saved_count} sign samples from {os.path.basename(tar_path)}.")
    return saved_count

def main():
    out_dir = os.path.join(ROOT, "data", "how2sign")
    os.makedirs(out_dir, exist_ok=True)
    
    under = {"LIBRARY", "NOT-UNDERSTAND", "GOODBYE", "APPOINTMENT", "BATHROOM", "TOMORROW", "DOCTOR", "SORRY", "CLASSROOM"}
    clip_to_gloss = load_clip_gloss_map(max_per_gloss=15, under_only=under)
    
    tar_train = os.path.join(ROOT, "data", "new data", "train_2D_keypoints.tar.gz")
    process_tarball(tar_train, clip_to_gloss, out_dir, max_frames=8000)

if __name__ == "__main__":
    main()
