"""Build the language-layer test set: eval/testset.jsonl

Each case = scripted conversation history + simulated recognizer output for the
next turn + what counts as a correct outcome. Recognition errors are injected
on purpose, so the language layer (Models A/B/C) can be evaluated on hundreds
of cases without anyone signing.

    python scripts/make_testset.py            # deterministic (seed 7)

Case fields
  category      which situation this tests (see CATEGORIES below)
  true_glosses  what the student actually signed
  segments      what the recognizer reports: [{gloss, conf, alts: [[gloss, p], ...]}]
  history       earlier turns (same format app.py stores)
  gold_intent   {act, topic}: the correct reading of the student's message
  acceptable    outcomes counted as correct: ["respond"], ["clarify"] or both.
                "respond" is only correct if the intent matches gold_intent.
"""
import json, os, random, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import llm  # noqa: E402

random.seed(7)
VOCAB = ["HELLO", "GOODBYE", "YES", "NO", "HELP", "THANK-YOU", "SORRY", "UNDERSTAND", "NOT-UNDERSTAND",
         "REPEAT", "WHERE", "WHAT", "WHO", "LIBRARY", "CLASSROOM", "BATHROOM", "FOOD", "WATER", "DOCTOR",
         "APPOINTMENT", "TOMORROW", "OFFICE", "WHEN"]
PLACES = ["LIBRARY", "CLASSROOM", "BATHROOM", "FOOD", "WATER", "DOCTOR", "OFFICE"]
QW = {"WHERE": "ask_location", "WHEN": "ask_time", "WHO": "ask_who", "WHAT": "ask_info"}
SOCIAL = {"HELLO": "greet", "GOODBYE": "farewell", "THANK-YOU": "thank", "SORRY": "apologize",
          "HELP": "request_help", "REPEAT": "request_repeat", "NOT-UNDERSTAND": "not_understood"}

CATEGORIES = {
    "clear":               "all signs recognised correctly with high confidence",
    "context_followup":    "a lone question sign (WHEN/WHERE/WHO/WHAT) that only makes sense with the earlier topic",
    "clarify_answer":      "student answers the assistant's 'X or Y?' question with one sign",
    "medium_supported":    "correct sign, medium confidence, earlier turns are about the same topic",
    "medium_unsupported":  "correct sign, medium confidence, no supporting context (asking or answering both OK)",
    "medium_wrong":        "wrong top-1 at medium confidence, true sign is the runner-up",
    "near_tie":            "top two candidates within 0.10, top-1 right or wrong",
    "low_conf":            "top-1 confidence below 0.50, right or wrong",
    "confident_wrong":     "wrong top-1 at high confidence (no system can catch this; reported separately)",
}


def r(a, b):
    return round(random.uniform(a, b), 2)


def other(g, pool=PLACES):
    return random.choice([x for x in pool if x != g])


def seg(gloss, conf, alts):
    return {"gloss": gloss, "conf": conf, "alts": [[a, p] for a, p in alts]}


def clean_seg(gloss, lo=0.85, hi=0.99):
    """Correct sign, high confidence, two small distractor alternatives."""
    c = r(lo, hi)
    pool = list(QW) if gloss in QW else [x for x in VOCAB if x != gloss]
    a1, a2 = random.sample([x for x in pool if x != gloss], 2)
    rest = round(1 - c, 2)
    p1 = round(rest * random.uniform(0.5, 0.8), 2)
    return seg(gloss, c, [(a1, p1), (a2, round(max(0.0, rest - p1), 2))])


def user_turn(glosses, intent):
    return {"role": "user", "content": f"[{' '.join(glosses)}] -> \"{llm.intent_to_text(intent)}\"",
            "glosses": glosses, "intent": intent}


def asst_turn(intent, history):
    return {"role": "assistant", "content": llm.kb_answer(intent, history), "clarification": False}


def history_about(topic, act=None):
    """One earlier exchange about `topic`, optionally preceded by a greeting."""
    h = []
    if random.random() < 0.5:
        gi = {"act": "greet", "topic": "NONE"}
        h += [user_turn(["HELLO"], gi), asst_turn(gi, h)]
    act = act or random.choice(["ask_location", "ask_time"])
    qw = {v: k for k, v in QW.items()}[act]
    it = {"act": act, "topic": topic}
    g = [qw, topic] if random.random() < 0.5 else [topic, qw]
    h += [user_turn(g, it), asst_turn(it, h)]
    return h


def unrelated_history(exclude):
    if random.random() < 0.4:
        return []
    return history_about(other(exclude))


def question(topic=None):
    topic = topic or random.choice(PLACES)
    qw = random.choice(["WHERE", "WHERE", "WHEN", "WHO"])
    g = [qw, topic] if random.random() < 0.5 else [topic, qw]     # ASL often puts the wh-sign last
    return g, {"act": QW[qw], "topic": topic}


def place_segments(glosses, place_seg):
    """All signs clean except the place sign, which gets `place_seg`."""
    return [place_seg if g in PLACES else clean_seg(g) for g in glosses]


cases = []


def add(cat, true_glosses, segments, history, gold, acceptable):
    cases.append({"id": f"{cat}-{sum(c['category'] == cat for c in cases):03d}", "category": cat,
                  "true_glosses": true_glosses, "segments": segments, "history": history,
                  "gold_intent": gold, "acceptable": acceptable})


# ---- clear
for _ in range(30):
    g, it = question()
    add("clear", g, [clean_seg(x) for x in g], unrelated_history(it["topic"]), it, ["respond"])
for gloss, act in SOCIAL.items():
    for _ in range(2):
        add("clear", [gloss], [clean_seg(gloss)], unrelated_history("NONE") if gloss != "REPEAT" else history_about(random.choice(PLACES)),
            {"act": act, "topic": "NONE"}, ["respond"])
for _ in range(6):
    g = random.choice([["DOCTOR", "APPOINTMENT", "WHEN"], ["APPOINTMENT", "WHEN"], ["WHEN", "APPOINTMENT"]])
    add("clear", g, [clean_seg(x) for x in g], [], {"act": "ask_time", "topic": "APPOINTMENT"}, ["respond"])

# ---- context follow-ups
for _ in range(24):
    topic = random.choice(PLACES)
    h = history_about(topic)
    qw = random.choice(["WHEN", "WHERE", "WHO", "WHAT"])
    add("context_followup", [qw], [clean_seg(qw)], h, {"act": QW[qw], "topic": topic}, ["respond"])

# ---- answering a clarification question
for _ in range(18):
    topic, wrong = random.sample(PLACES, 2)
    qw = random.choice(["WHERE", "WHEN"])
    h = []
    pend = {"act": QW[qw], "topic": topic}
    shown = [topic, wrong] if random.random() < 0.5 else [wrong, topic]
    h.append({"role": "user", "content": f"[{qw} {shown[0]}]", "glosses": [qw, shown[0]], "intent": None})
    h.append({"role": "assistant", "clarification": True, "pending_intent": {"act": pend["act"], "topic": shown[0]},
              "content": f"I'm not sure whether you signed \"{llm.WORD[shown[0]]}\" or \"{llm.WORD[shown[1]]}\". Which one did you mean?"})
    add("clarify_answer", [topic], [clean_seg(topic)], h, pend, ["respond"])

# ---- medium confidence, correct, supported by context
for _ in range(18):
    g, it = question()
    c = r(0.55, 0.75)
    alt = other(it["topic"])
    pa = round(random.uniform(0.05, c - 0.2), 2)
    add("medium_supported", g, place_segments(g, seg(it["topic"], c, [(alt, pa)])),
        history_about(it["topic"]), it, ["respond"])

# ---- medium confidence, correct, no context
for _ in range(18):
    g, it = question()
    c = r(0.55, 0.75)
    alt = other(it["topic"])
    pa = round(random.uniform(0.05, c - 0.15), 2)
    add("medium_unsupported", g, place_segments(g, seg(it["topic"], c, [(alt, pa)])),
        unrelated_history(it["topic"]), it, ["respond", "clarify"])

# ---- medium confidence, wrong top-1 (true sign is runner-up)
for i in range(24):
    g, it = question()
    wrong = other(it["topic"])
    c = r(0.55, 0.75)
    pt = round(random.uniform(0.10, c - 0.12), 2)
    if i % 2 == 0:   # context points to the true topic: answering with the true topic is also fine
        h, acc = history_about(it["topic"]), ["clarify", "respond"]
    else:
        h, acc = unrelated_history(it["topic"]), ["clarify"]
    add("medium_wrong", g, place_segments(g, seg(wrong, c, [(it["topic"], pt)])), h, it, acc)

# ---- near ties
for i in range(20):
    g, it = question()
    wrong = other(it["topic"])
    hi_p = r(0.44, 0.56)
    lo_p = round(hi_p - random.uniform(0.0, 0.09), 2)
    top, alt = (it["topic"], wrong) if i % 2 == 0 else (wrong, it["topic"])
    add("near_tie", g, place_segments(g, seg(top, hi_p, [(alt, lo_p)])), unrelated_history(it["topic"]), it, ["clarify"])
for i in range(6):   # social near-tie: HELP vs HELLO
    true, wrong = ("HELP", "HELLO") if i % 2 == 0 else ("HELLO", "HELP")
    hi_p = r(0.42, 0.52)
    top, alt = (true, wrong) if i < 3 else (wrong, true)
    add("near_tie", [true], [seg(top, hi_p, [(alt, round(hi_p - 0.03, 2))])], [],
        {"act": SOCIAL[true], "topic": "NONE"}, ["clarify"])

# ---- low confidence
for i in range(20):
    g, it = question()
    wrong = other(it["topic"])
    c = r(0.25, 0.48)
    pa = round(random.uniform(0.05, c - 0.12), 2)
    top, alt = (it["topic"], wrong) if i % 2 == 0 else (wrong, it["topic"])
    add("low_conf", g, place_segments(g, seg(top, c, [(alt, pa)])), unrelated_history(it["topic"]), it, ["clarify"])

# ---- confident but wrong (limitation)
for _ in range(10):
    g, it = question()
    wrong = other(it["topic"])
    c = r(0.85, 0.97)
    add("confident_wrong", g, place_segments(g, seg(wrong, c, [(it["topic"], round(1 - c, 2))])),
        unrelated_history(it["topic"]), it, ["clarify"])

os.makedirs(os.path.join(ROOT, "eval"), exist_ok=True)
out = os.path.join(ROOT, "eval", "testset.jsonl")
with open(out, "w") as f:
    for c in cases:
        f.write(json.dumps(c) + "\n")
counts = {}
for c in cases:
    counts[c["category"]] = counts.get(c["category"], 0) + 1
print(f"wrote {len(cases)} cases to {out}")
for k, v in counts.items():
    print(f"  {k:20s} {v:4d}  {CATEGORIES[k]}")
