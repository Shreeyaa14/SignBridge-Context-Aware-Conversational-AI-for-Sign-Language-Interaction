#!/usr/bin/env bash
# Package clean project submission zip archive (excluding .venv and raw 21GB tarballs)
set -e
DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$DIR"

OUT_ZIP="signbridge_submission.zip"
echo "Creating clean submission package: $OUT_ZIP ..."
rm -f "$OUT_ZIP"

zip -r "$OUT_ZIP" . \
  -x ".venv/*" \
  -x "data/new data/*.tar.gz" \
  -x "data/new data/*.download/*" \
  -x ".git/*" \
  -x "__pycache__/*" \
  -x "*/__pycache__/*" \
  -x "*.pyc" \
  -x ".DS_Store" \
  -x "*/.DS_Store"

echo "✓ Successfully created $OUT_ZIP ($(du -sh "$OUT_ZIP" | cut -f1))"

